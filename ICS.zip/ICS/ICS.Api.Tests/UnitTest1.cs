using System;
using Xunit;

namespace ICS.Api.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
